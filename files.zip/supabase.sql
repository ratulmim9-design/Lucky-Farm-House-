-- Lucky Farm House: run this whole file once in Supabase > SQL Editor
create table if not exists public.cows(id bigint generated always as identity primary key, name text not null, breed text, age text, weight text, milk text, price text, status text default 'a', img text, created_at timestamptz default now());
create table if not exists public.products(id bigint generated always as identity primary key, name text not null, unit text, price text, img text, created_at timestamptz default now());
create table if not exists public.veg(id bigint generated always as identity primary key, name text not null, unit text, price text, stock text, src text, img text,
 m0 int,m1 int,m2 int,m3 int,m4 int,m5 int,m6 int,m7 int,m8 int,m9 int,m10 int,m11 int, created_at timestamptz default now());
create table if not exists public.settings(id int primary key check (id=1), phone text, wa text);
insert into public.settings values (1,'01708091859','8801708091859') on conflict do nothing;
create table if not exists public.admins(user_id uuid primary key references auth.users(id) on delete cascade);

create or replace function public.is_admin() returns boolean language sql security definer stable set search_path=public as
$$ select exists(select 1 from public.admins where user_id=auth.uid()) $$;

do $$ declare t text; begin
 foreach t in array array['cows','products','veg','settings'] loop
  execute format('alter table public.%I enable row level security',t);
  execute format('drop policy if exists "public read" on public.%I',t);
  execute format('create policy "public read" on public.%I for select using (true)',t);
  execute format('drop policy if exists "admin write" on public.%I',t);
  execute format('create policy "admin write" on public.%I for all to authenticated using (public.is_admin()) with check (public.is_admin())',t);
 end loop;
end $$;
alter table public.admins enable row level security;
revoke all on public.admins from anon, authenticated;

-- Image storage: public read, admin-only write, 5 MB, jpg/png/webp only
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values('images','images',true,5242880,array['image/jpeg','image/png','image/webp'])
on conflict (id) do update set public=true,file_size_limit=5242880,allowed_mime_types=array['image/jpeg','image/png','image/webp'];
drop policy if exists "img insert" on storage.objects; drop policy if exists "img update" on storage.objects; drop policy if exists "img delete" on storage.objects;
create policy "img insert" on storage.objects for insert to authenticated with check (bucket_id='images' and public.is_admin());
create policy "img update" on storage.objects for update to authenticated using (bucket_id='images' and public.is_admin());
create policy "img delete" on storage.objects for delete to authenticated using (bucket_id='images' and public.is_admin());

-- AFTER creating your admin user in Authentication > Users, run this (put YOUR email):
-- insert into public.admins(user_id) select id from auth.users where email='YOUR_EMAIL_HERE';

# Lucky Farm House – setup (Supabase + secure admin)
Files: index.html, style.css, app.js, config.js, supabase.sql, _headers, robots.txt, sitemap.xml, images/

1. Create a free project at supabase.com.
2. SQL Editor: paste all of supabase.sql and Run.
3. Authentication > Users > Add user (your email + a long unique password).
4. Authentication > Sign In / Providers: turn OFF "Allow new users to sign up". Authentication > URL Configuration: set Site URL to https://luckyfarmhouse.com.bd
5. SQL Editor: run the last (commented) line of supabase.sql with your email, to make yourself admin.
6. Project Settings > API: copy Project URL and anon public key into config.js. Never use the service_role key.
7. Upload the whole folder to Netlify or Cloudflare Pages (they apply _headers; GitHub Pages ignores it). Connect your domain.
8. Open yoursite/#/admin and log in.
Keep your email account protected with 2-step verification. Do not share the password.

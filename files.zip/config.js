// Paste your Supabase values (Project Settings > API). The anon key is public by design; the database rules protect your data.
// NEVER paste the service_role key here.
window.LFH_CONFIG={url:'YOUR_SUPABASE_URL',key:'YOUR_SUPABASE_ANON_KEY'};

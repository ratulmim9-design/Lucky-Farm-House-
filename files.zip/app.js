
const $=(s,e=document)=>e.querySelector(s),$$=(s,e=document)=>[...e.querySelectorAll(s)];
const T={bn:{n_home:'হোম',n_cows:'গরু বিক্রয়',n_prod:'ডেইরি পণ্য',n_veg:'সবজি',veg_sub:'তাজা সবজি ও মৌসুমি চাহিদা',stock:'স্টক',season:'মৌসুমি চাহিদা',src:'তথ্যসূত্র',nosrc:'মৌসুমি তথ্য শীঘ্রই',n_about:'আমাদের সম্পর্কে',n_farm:'খামার তথ্য',n_contact:'যোগাযোগ',
h_title:'খাঁটি ডেইরি, <span>সেরা হলস্টেইন ফ্রিজিয়ান</span> গরু',h_sub:'সিংগাইর, মানিকগঞ্জের লাকি ফার্ম হাউসে পাবেন স্বাস্থ্যবান গরু, বাছুর ও বিশ্বস্ত ডেইরি পণ্য।',h_cta1:'গরু দেখুন',h_cta2:'আমাদের পণ্য',
st1:'খাঁটি ও বিশ্বস্ত',st2:'হলস্টেইন ফ্রিজিয়ান',st3:'তাজা ডেইরি',st4:'সিংগাইর, মানিকগঞ্জ',
feat_cows:'নির্বাচিত গরু',view_all:'সব গরু দেখুন',why:'কেন লাকি ফার্ম হাউস?',cta_t:'গরু বা পণ্য সম্পর্কে জানতে এখনই মেসেজ করুন',wa_btn:'WhatsApp-এ মেসেজ করুন',
cows_sub:'বয়স, ওজন ও দুধ উৎপাদনের তথ্যসহ',prod_sub:'তাজা ও মানসম্মত ডেইরি পণ্য',search:'গরু খুঁজুন...',
ab_h:'আমাদের গল্প',ab_p:'লাকি ফার্ম হাউস সিংগাইর, মানিকগঞ্জে অবস্থিত একটি আধুনিক ডেইরি খামার। আমরা হলস্টেইন ফ্রিজিয়ান জাতের গরু পালন করি এবং খামারিদের জন্য স্বচ্ছ তথ্যসহ গরু সরবরাহ করি।',
mv_h:'আমাদের লক্ষ্য',mv_p:'সৎ তথ্য, ভালো যত্ন ও আস্থার সঙ্গে বাংলাদেশের ডেইরি খাতকে এগিয়ে নেওয়া।',loc:'অবস্থান',reach:'সরাসরি যোগাযোগ',call:'কল করুন',msg:'মেসেজ পাঠান',
f_name:'আপনার নাম',f_phone:'ফোন নম্বর',f_msg:'বার্তা',send:'WhatsApp-এ পাঠান',
age:'বয়স',wt:'ওজন',milk:'দৈনিক দুধ',breed:'জাত',price:'দাম',callp:'দামের জন্য কল করুন',avail:'বিক্রয়ের জন্য',sold:'বিক্রিত',order:'অর্ডার করুন',ask:'WhatsApp',call2:'কল',unit:'একক',empty:'কোনো তথ্য নেই'},
en:{n_home:'Home',n_cows:'Cows for Sale',n_prod:'Dairy Products',n_veg:'Vegetables',veg_sub:'Fresh vegetables and seasonal demand',stock:'Stock',season:'Seasonal demand',src:'Source',nosrc:'Seasonal data coming soon',n_about:'About Us',n_farm:'Farm Info',n_contact:'Contact',
h_title:'Pure Dairy, <span>Premium Holstein Friesian</span> Cattle',h_sub:'Healthy cows, calves and trusted dairy products from Lucky Farm House, Singair, Manikganj.',h_cta1:'View Cows',h_cta2:'Our Products',
st1:'Pure & Trusted',st2:'Holstein Friesian',st3:'Fresh Dairy',st4:'Singair, Manikganj',
feat_cows:'Featured Cows',view_all:'View All Cows',why:'Why Lucky Farm House?',cta_t:'Message us now about cows or products',wa_btn:'Message on WhatsApp',
cows_sub:'With age, weight and milk production details',prod_sub:'Fresh, quality dairy products',search:'Search cows...',
ab_h:'Our Story',ab_p:'Lucky Farm House is a modern dairy farm in Singair, Manikganj. We raise Holstein Friesian cattle and supply cows to farmers with transparent information.',
mv_h:'Our Mission',mv_p:'To move Bangladesh dairy forward with honest information, good care and trust.',loc:'Location',reach:'Get in touch',call:'Call Now',msg:'Send a message',
f_name:'Your name',f_phone:'Phone number',f_msg:'Message',send:'Send via WhatsApp',
age:'Age',wt:'Weight',milk:'Daily milk',breed:'Breed',price:'Price',callp:'Call for price',avail:'Available',sold:'Sold',order:'Order',ask:'WhatsApp',call2:'Call',unit:'Unit',empty:'No items'}};
const WHY=[['🩺',{bn:'স্বাস্থ্য যত্ন',en:'Health Care'},{bn:'নিয়মিত ভ্যাকসিন ও পরীক্ষা',en:'Regular vaccination and checks'}],
['🌾',{bn:'সুষম খাদ্য',en:'Balanced Feed'},{bn:'পুষ্টিকর খাদ্য ব্যবস্থাপনা',en:'Nutritious feed management'}],
['🤝',{bn:'স্বচ্ছ তথ্য',en:'Transparent Info'},{bn:'বয়স, ওজন ও দুধের সঠিক তথ্য',en:'Honest age, weight and milk data'}],
['📞',{bn:'সরাসরি সেবা',en:'Direct Support'},{bn:'ফোন ও WhatsApp-এ যোগাযোগ',en:'Reach us by phone and WhatsApp'}]];
const FARM=[['🏠',{bn:'আধুনিক শেড',en:'Modern Sheds'},{bn:'আলো-বাতাসপূর্ণ গরুর থাকার ব্যবস্থা',en:'Ventilated, well-lit housing'}],
['💧',{bn:'পরিষ্কার পানি',en:'Clean Water'},{bn:'সার্বক্ষণিক নিরাপদ পানি',en:'Safe drinking water'}],
['🌱',{bn:'ঘাস ও সাইলেজ',en:'Fodder & Silage'},{bn:'নিজস্ব ঘাস চাষ',en:'Own fodder cultivation'}],
['🐮',{bn:'বাছুর পরিচর্যা',en:'Calf Care'},{bn:'বাছুরের বিশেষ যত্ন',en:'Special calf management'}]];
const CFG=window.LFH_CONFIG||{};
const live=CFG.url&&CFG.key&&!/YOUR_/.test(CFG.url+CFG.key);
const sb=live&&window.supabase?window.supabase.createClient(CFG.url,CFG.key):null;
let D={settings:{phone:'01708091859',wa:'8801708091859'},cows:[],products:[],veg:[]},lang=localStorage.getItem('lfh_lang')||'bn',admin=false;
const safeImg=u=>/^https:\/\/[a-z0-9-]+\.supabase\.co\//.test(u||'')?u:'';
async function loadAll(){if(!sb)return;
 const q=n=>sb.from(n).select('*').order('id',{ascending:false});
 const[c,p,v,s]=await Promise.all([q('cows'),q('products'),q('veg'),sb.from('settings').select('*').eq('id',1).maybeSingle()]);
 if(c.data)D.cows=c.data;if(p.data)D.products=p.data;if(v.data)D.veg=v.data;if(s.data)D.settings={phone:s.data.phone,wa:s.data.wa}}
const t=k=>T[lang][k]||k,esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function toast(m){const e=$('#toast');e.textContent=m;e.classList.add('on');setTimeout(()=>e.classList.remove('on'),2200)}
const wa=(m='')=>`https://wa.me/${D.settings.wa}?text=${encodeURIComponent(m)}`;
function cowCard(c){const sold=c.status==='s';
 return `<article class="card rv"><div class="ph">${safeImg(c.img)?`<img loading="lazy" src="${safeImg(c.img)}" alt="${esc(c.name)}">`:'🐄'}<span class="tag ${sold?'sold':''}">${sold?t('sold'):t('avail')}</span></div><div class="cb"><h3>${esc(c.name)}</h3>
 <div class="spec"><span>${t('breed')}: <b>${esc(c.breed)}</b></span><span>${t('age')}: <b>${esc(c.age)}</b></span><span>${t('wt')}: <b>${esc(c.weight)}</b></span><span>${t('milk')}: <b>${esc(c.milk)}</b></span></div>
 <div class="price">${c.price?'৳ '+esc(c.price):t('callp')}</div>
 <div class="acts"><a class="btn wa sm" target="_blank" rel="noopener" href="${wa('Lucky Farm House: '+c.name)}">${t('ask')}</a><a class="btn g sm" href="tel:${D.settings.phone}">${t('call2')}</a></div></div></article>`}
function prodCard(p){return `<article class="card rv"><div class="ph">${safeImg(p.img)?`<img loading="lazy" src="${safeImg(p.img)}" alt="${esc(p.name)}">`:'🥛'}</div><div class="cb"><h3>${esc(p.name)}</h3><span style="color:var(--m)">${t('unit')}: ${esc(p.unit)}</span>
 <div class="price">${p.price?'৳ '+esc(p.price):t('callp')}</div><a class="btn wa sm" style="align-self:flex-start" target="_blank" rel="noopener" href="${wa('Order: '+p.name)}">${t('order')}</a></div></article>`}
const MON={bn:['জা','ফে','মা','এ','মে','জুন','জুল','আ','সে','অ','ন','ডি'],en:['J','F','M','A','M','J','J','A','S','O','N','D']};
function vegCard(v){const a=Array.from({length:12},(_,i)=>Math.min(100,Math.max(0,+v['m'+i]||0)));const has=a.some(x=>x>0)&&v.src;
 const ch=has?`<div style="font-size:.85rem;color:var(--m)">${t('season')}</div><svg viewBox="0 0 240 78" role="img" aria-label="${t('season')}">${a.map((x,i)=>`<rect x="${i*20+3}" y="${60-x*.55}" width="14" height="${x*.55}" rx="3" fill="var(--g2)"/><text x="${i*20+10}" y="74" font-size="9" text-anchor="middle" fill="#5c6b62">${MON[lang][i]}</text>`).join('')}</svg><div style="font-size:.78rem;color:var(--m)">${t('src')}: ${esc(v.src)}</div>`:`<div style="font-size:.85rem;color:var(--m)">${t('nosrc')}</div>`;
 return `<article class="card rv"><div class="ph">${safeImg(v.img)?`<img loading="lazy" src="${safeImg(v.img)}" alt="${esc(v.name)}">`:'🥬'}</div><div class="cb"><h3>${esc(v.name)}</h3><span style="color:var(--m)">${t('unit')}: ${esc(v.unit)} · ${t('stock')}: ${esc(v.stock||'—')}</span><div class="price">${v.price?'৳ '+esc(v.price):t('callp')}</div>${ch}<a class="btn wa sm" style="align-self:flex-start" target="_blank" rel="noopener" href="${wa('Order: '+v.name)}">${t('order')}</a></div></article>`}
const info=a=>a.map(x=>`<div class="f rv"><i>${x[0]}</i><h3>${x[1][lang]}</h3><p>${x[2][lang]}</p></div>`).join('');
function render(){
 D.veg=D.veg||[];
 document.documentElement.lang=lang;$('#lang').textContent=lang==='bn'?'EN':'বাং';
 $$('[data-i]').forEach(e=>e.innerHTML=t(e.dataset.i));$$('[data-ph]').forEach(e=>e.placeholder=t(e.dataset.ph));
 $$('.wa-link').forEach(a=>a.href=wa('Hello Lucky Farm House'));
 $$('.tel').forEach(a=>a.href='tel:'+D.settings.phone);
 $('#homeCows').innerHTML=D.cows.slice(0,3).map(cowCard).join('')||t('empty');
 $('#homeProd').innerHTML=D.products.slice(0,3).map(prodCard).join('')||t('empty');
 $('#why').innerHTML=info(WHY);$('#farmInfo').innerHTML=info(FARM);
 $('#vegGrid').innerHTML=D.veg.map(vegCard).join('')||t('empty');filterCows();$('#prodGrid').innerHTML=D.products.map(prodCard).join('')||t('empty');
 if(location.hash==='#/admin')renderAdmin();observe();
}
function filterCows(){const q=$('#q').value.toLowerCase();$('#cowGrid').innerHTML=D.cows.filter(c=>(c.name+c.breed).toLowerCase().includes(q)).map(cowCard).join('')||t('empty');observe()}
$('#q').addEventListener('input',filterCows);
function observe(){const io=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){e.target.classList.add('in');io.unobserve(e.target)}}),{threshold:.1});$$('.rv:not(.in)').forEach(e=>io.observe(e))}
function route(){const h=(location.hash||'#/').slice(2)||'home';const id='p-'+(['cows','products','veg','about','farm','contact','admin'].includes(h)?h:'home');
 $$('.page').forEach(p=>p.classList.toggle('on',p.id===id));
 $$('nav a.l').forEach(a=>a.classList.toggle('on',a.getAttribute('href')==='#/'+(h==='home'?'':h)));
 $('#menu').classList.remove('open');window.scrollTo({top:0,behavior:'smooth'});if(id==='p-admin')renderAdmin();observe()}
addEventListener('hashchange',route);
$('#burger').onclick=()=>$('#menu').classList.toggle('open');
$('#lang').onclick=()=>{lang=lang==='bn'?'en':'bn';localStorage.setItem('lfh_lang',lang);render()};
$('#send').onclick=()=>{const m=`Name: ${$('#cn').value}\nPhone: ${$('#cp').value}\n${$('#cm').value}`;window.open(wa(m),'_blank','noopener')};
/* ---------- Admin: Supabase Auth + Row Level Security ---------- */
let tab='cows',edit=null,fails=0,lock=0;
async function isAdmin(){if(!sb)return false;const{data:{session}}=await sb.auth.getSession();if(!session)return false;const{data}=await sb.rpc('is_admin');return data===true}
async function renderAdmin(){const r=$('#adminRoot');
 if(!sb){r.innerHTML='<div class="box"><h3>Setup needed</h3><p>Fill config.js with your Supabase URL and anon key (see README).</p></div>';return}
 if(!admin)admin=await isAdmin();
 if(!admin){r.innerHTML=`<div class="box" style="max-width:380px;margin:auto"><h3>Admin Login</h3><input id="em" type="email" autocomplete="username" placeholder="Email"><input id="pw" type="password" autocomplete="current-password" placeholder="Password"><button class="btn g" id="lg">Login</button></div>`;
  $('#lg').onclick=async()=>{if(Date.now()<lock)return toast('Wait 60 seconds');
   const{error}=await sb.auth.signInWithPassword({email:$('#em').value.trim(),password:$('#pw').value});
   if(error){if(++fails>=5){lock=Date.now()+60000;fails=0}return toast('Login failed')}
   admin=await isAdmin();if(!admin){await sb.auth.signOut();return toast('Not an admin')}renderAdmin()};return}
 r.innerHTML=`<div class="tabs">${['cows','products','veg','settings'].map(x=>`<button class="${tab===x?'on':''}" data-t="${x}">${x}</button>`).join('')}<button id="bk">Backup</button><button id="lo">Logout</button></div><div id="tabBody"></div>`;
 $$('[data-t]').forEach(b=>b.onclick=()=>{tab=b.dataset.t;edit=null;renderAdmin()});
 $('#lo').onclick=async()=>{await sb.auth.signOut();admin=false;renderAdmin()};
 $('#bk').onclick=()=>{const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([JSON.stringify(D)],{type:'application/json'}));a.download='luckyfarm-backup.json';a.click()};
 const b=$('#tabBody');
 if(tab==='settings'){b.innerHTML=`<div class="box"><div class="frm"><div><label>Phone</label><input id="s1" value="${esc(D.settings.phone)}"></div><div><label>WhatsApp (8801XXXXXXXXX)</label><input id="s2" value="${esc(D.settings.wa)}"></div><div class="full"><label>New password (min 12 characters)</label><input id="s3" type="password" autocomplete="new-password" placeholder="leave empty to keep"></div></div><button class="btn y" id="ss">Save</button></div>`;
  $('#ss').onclick=async()=>{const p=$('#s3').value;if(p&&p.length<12)return toast('Password: minimum 12 characters');
   const x=await sb.from('settings').update({phone:$('#s1').value.trim(),wa:$('#s2').value.trim()}).eq('id',1);if(x.error)return toast('Save failed');
   if(p){const y=await sb.auth.updateUser({password:p});if(y.error)return toast('Password not changed')}
   await loadAll();render();toast('Saved')};return}
 const list=D[tab],isC=tab==='cows';
 const F=isC?[['name','Name'],['breed','Breed'],['age','Age'],['weight','Weight'],['milk','Milk / day'],['price','Price (BDT)']]:tab==='veg'?[['name','Name'],['unit','Unit'],['price','Price (BDT)'],['stock','Stock']]:[['name','Name'],['unit','Unit'],['price','Price (BDT)']];
 const cur=edit!==null?list.find(x=>x.id===edit)||{}:{};
 b.innerHTML=`<div class="box" style="margin-bottom:22px"><h3>${edit!==null?'Edit':'Add'}</h3><div class="frm">${F.map(f=>`<div><label>${f[1]}</label><input data-f="${f[0]}" value="${esc(cur[f[0]]||'')}"></div>`).join('')}
 ${isC?`<div><label>Status</label><select data-f="status"><option value="a" ${cur.status!=='s'?'selected':''}>Available</option><option value="s" ${cur.status==='s'?'selected':''}>Sold</option></select></div>`:''}
 ${tab==='veg'?`<div class="full"><label>Seasonal demand Jan→Dec (0–100). Enter only real data</label><div style="display:grid;grid-template-columns:repeat(6,1fr);gap:6px">${[...Array(12)].map((_,i)=>`<input data-f="m${i}" inputmode="numeric" placeholder="${i+1}" value="${esc(cur['m'+i]??'')}" style="margin:0">`).join('')}</div></div><div class="full"><label>Data source (chart shows only if filled)</label><input data-f="src" value="${esc(cur.src||'')}"></div>`:''}
 <div class="full"><label>Photo (JPG/PNG/WebP)</label><input type="file" id="im" accept="image/jpeg,image/png,image/webp"></div></div><button class="btn y" id="sv">Save</button> ${edit!==null?'<button class="btn g" id="cx">Cancel</button>':''}</div>
 <div class="box" style="overflow:auto"><table><tr><th>Name</th><th>Price</th><th></th></tr>${list.map(x=>`<tr><td>${esc(x.name)}</td><td>${esc(x.price||'—')}</td><td><button class="btn g sm" data-e="${x.id}">Edit</button> <button class="btn sm" style="background:#b3261e;color:#fff" data-d="${x.id}">Delete</button></td></tr>`).join('')}</table></div>`;
 $$('[data-e]').forEach(x=>x.onclick=()=>{edit=+x.dataset.e;renderAdmin()});
 $$('[data-d]').forEach(x=>x.onclick=async()=>{if(!confirm('Delete?'))return;const r=await sb.from(tab).delete().eq('id',+x.dataset.d);if(r.error)return toast('Delete failed');await loadAll();render()});
 if($('#cx'))$('#cx').onclick=()=>{edit=null;renderAdmin()};
 $('#sv').onclick=async()=>{const o={};$$('[data-f]',b).forEach(i=>o[i.dataset.f]=i.value.trim());
  if(!o.name)return toast('Name required');
  for(const k in o)if(/^m\d+$/.test(k))o[k]=o[k]===''?null:Math.min(100,Math.max(0,Math.round(+o[k]||0)));
  const f=$('#im').files[0];
  if(f){if(!/^image\/(jpeg|png|webp)$/.test(f.type)||f.size>15e6)return toast('Only JPG/PNG/WebP under 15 MB');
   const path=crypto.randomUUID()+'.jpg',up=await sb.storage.from('images').upload(path,await shrink(f),{contentType:'image/jpeg'});
   if(up.error)return toast('Upload failed');o.img=sb.storage.from('images').getPublicUrl(path).data.publicUrl}
  const res=edit!==null?await sb.from(tab).update(o).eq('id',edit):await sb.from(tab).insert(o);
  if(res.error)return toast('Save failed');
  edit=null;await loadAll();render();toast('Saved')};
}
function shrink(file){return new Promise(res=>{const im=new Image();im.onload=()=>{const s=Math.min(1,900/im.width),c=document.createElement('canvas');c.width=im.width*s;c.height=im.height*s;c.getContext('2d').drawImage(im,0,0,c.width,c.height);c.toBlob(res,'image/jpeg',.75)};im.src=URL.createObjectURL(file)})}
render();route();loadAll().then(render);

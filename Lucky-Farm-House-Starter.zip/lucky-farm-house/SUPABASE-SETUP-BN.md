# নিরাপদ Admin ও Online Database সেটআপ — বাংলা নির্দেশিকা

## এখনকার অবস্থা
এই ZIP-এ ওয়েবসাইটের public-facing starter আছে। Admin login ইচ্ছাকৃতভাবে বন্ধ, কারণ
শুধু HTML/JavaScript দিয়ে নিরাপদ ব্যক্তিগত লগইন করা যায় না। GitHub Pages-এ প্রকাশিত
JavaScript ও ফাইল সবাই দেখতে পারে। তাই কোনো পাসওয়ার্ড কোডে রাখা যাবে না।

## Supabase দিয়ে পরের ধাপ
1. Supabase-এ একটি নতুন Project তৈরি করুন।
2. Authentication → Providers-এ Email provider চালু রাখুন।
3. Authentication → Users থেকে শুধু মালিকের জন্য একটি user তৈরি করুন।
4. Project Settings → API থেকে Project URL ও anon/publishable key নিন।
5. Database-এ `profiles`, `products`, `cows`, `orders`, `inventory`,
   `farm_records`, `suppliers`, `affiliate_products` টেবিল তৈরি করুন।
6. প্রতিটি টেবিলে Row Level Security (RLS) চালু করুন।
7. Public visitor-দের শুধু প্রকাশযোগ্য product/cow তথ্য পড়ার অনুমতি দিন।
8. Insert/update/delete কেবল authenticated owner account-কে দিন।
9. Admin UI-কে Supabase Auth session দিয়ে গেট করুন; database query-তেও RLS enforce করুন।
10. Test করুন: লগআউট অবস্থায় admin data পরিবর্তন করা যায় কি না, অন্য user access পায় কি না।

## নিরাপত্তা
- `service_role` key কখনো browser code বা GitHub-এ দেবেন না।
- Admin password HTML/JS/localStorage-এ রাখবেন না।
- GitHub repository public হলে সব committed code public ধরে নেবেন।
- প্রকৃত গ্রাহকের ফোন, ঠিকানা বা অর্ডারের তথ্য public table-এ প্রকাশ করবেন না।

## এখনো যেগুলো সম্পূর্ণভাবে চালু হয়নি
- Supabase database/auth connection ও RLS policies
- Real online order storage and owner notifications
- Farm health, milk production and expense records
- Supplier wholesale purchase and margin management
- Affiliate link/click/sales tracking (partner program support অনুযায়ী)
- Google AdSense approval and ad placement
- Android app

এসব আলাদা করে implement, configure ও test করতে হবে। এই ZIP-কে সম্পূর্ণ backend বা
production-ready secure marketplace মনে করবেন না।

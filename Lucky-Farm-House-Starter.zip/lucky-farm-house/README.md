# Lucky Farm House — Website Starter

A responsive Bengali/English website starter for Lucky Farm House, Singair, Manikganj.

## Included
- Premium forest-green and gold visual theme
- Home, cows, dairy products, About, farm information and contact pages
- Bengali/English language switch
- WhatsApp contact links and sample cow/product cards
- Mobile-responsive layout
- About Us copy expanded with transparent product and animal information

## Important security notice
This is a **website starter**, not a completed production marketplace.
The old browser-only admin login used a password embedded in public JavaScript and localStorage.
That unsafe login has been removed. The Admin page is intentionally locked until Supabase
Authentication, database tables, and Row Level Security policies are configured.

Do not add an admin password to `index.html`, JavaScript, GitHub, or any public file.
Do not put a Supabase `service_role` key in frontend code. Only the Supabase anon/publishable
key may be used in the browser, with correct Row Level Security policies.

## Run locally
Open `index.html` in a browser, or deploy the folder to GitHub Pages.

## Before production
Read `SUPABASE-SETUP-BN.md`. Real online orders, stock, farm records, supplier management,
affiliate tracking, AdSense and a native mobile app require further integration and testing.
